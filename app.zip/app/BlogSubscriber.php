<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BlogSubscriber extends Model
{
    //

    protected $fillable=['email'];

}
