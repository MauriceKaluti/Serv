<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FanakaTest extends Model
{
    //
    protected $fillable=['user_id','user_name','email','phone','sacco_name','vehicle_driver','vehicle_reg','county','town'];
}
